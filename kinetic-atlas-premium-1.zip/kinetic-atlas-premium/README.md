# KINETIC ATLAS — Premium Static E-commerce Prototype

A premium, responsive, static fashion storefront built around the supplied Kinetic Atlas visual direction.

## Included
- Premium light sage / ivory design system
- Responsive home, shop, product, account and checkout pages
- Interactive kinetic thread canvas
- Pointer-driven 3D hero tilt / depth effect
- Glass/refraction-style overlays and editorial art direction
- Product filtering, search modal, wishlist state and persistent localStorage cart
- Quantity controls, cart drawer, subtotal and demo checkout
- Product structured data (JSON-LD), Organization/WebSite schemas
- robots.txt, sitemap.xml and PWA manifest starter
- Supplied image assets renamed and organized under `assets/images/`

## Run locally
Because this is a static site, you can open `index.html` directly. For best browser behaviour, use a local server, e.g. VS Code Live Server or `python -m http.server` inside this folder.

## Production connections still required
This package is a front-end implementation. Real commerce requires a secure commerce/payment back end. Recommended options: Shopify Storefront + Checkout, WooCommerce REST/Store API, Medusa, Saleor, or a custom Node/Next back end. Payments should use Stripe/Shopify/PayPal hosted PCI-compliant components. Authentication, inventory, tax, shipping quotes, coupons, order persistence, email, analytics consent and fulfilment APIs must be connected to production services.

## Main files
- `index.html` — flagship landing page
- `shop.html` — catalog / filters
- `product.html?id=club-crew` — dynamic product detail template
- `checkout.html` — secure checkout UI prototype
- `account.html` — customer auth UI prototype
- `assets/js/data.js` — product data
- `assets/js/app.js` — cart, search, wishlist, animation, interactions
- `assets/css/styles.css` — full responsive design system

## Product IDs
`club-crew`, `retro-crew`, `movement-crew`, `atlas-retro`, `midnight-oversized`, `fabric-edition`
